package com.laptopshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaptopShopManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
