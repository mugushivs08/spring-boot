package com.laptopshop.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.laptopshop.entity.Laptop;

@Repository
public interface LaptopRepository extends JpaRepository<Laptop, Integer>{
	@Query("select sum(m.lprice) from Laptop m")
	float totalLaptopPrice();

	Laptop findByLaptopname(String lname);
}
