package com.laptopshop.controller;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.laptopshop.entity.Customer;
import com.laptopshop.error.CustomerNotFoundException;
import com.laptopshop.repository.CustomerRepository;
import com.laptopshop.service.CustomerService;

@RestController
public class CustomerController {
@Autowired
private CustomerService customerService;
@Autowired
private CustomerRepository customerRepository;

//add
@PostMapping("/customer")
public ResponseEntity<Customer> addCustomer(@Valid @RequestBody Customer customer) {
	Customer saveCustomer=customerService.addCustomer(customer);
	return new ResponseEntity<Customer>(saveCustomer,HttpStatus.CREATED);	
}

//view
@GetMapping("/customer")
public List<Customer> getAllCustomers(){
	return customerService.getAllCustomers();
}

//delete
@DeleteMapping("/customer/{cid}")
public String deleteCustomer(@PathVariable("cid")Integer cid) throws CustomerNotFoundException   {
	customerService.deleteCustomer(cid);
	return "Customer deleted successfully";
}

//update
@PutMapping("/customer/{cid}")
public Customer updateCustomer(@PathVariable("cid")Integer cid, @RequestBody Customer customer) throws CustomerNotFoundException { 
	 return customerService.updateCustomer(cid,customer);
	 }

//find by id	
	@GetMapping("/customer/{cid}")
	 public Customer findById(@PathVariable("cid")Integer cid) throws CustomerNotFoundException { 
		return customerService.findById(cid);	 
	}
	
//Customer total payamount
	@GetMapping("/customertotalpayamount")
	 public float totalpayAmount() {
		 return customerRepository.totalpayAmount();
	 }
	
//find by name	
		@GetMapping("/customername/{cname}")
		 public Customer findByCustomername(@PathVariable("cname")String cname) throws CustomerNotFoundException    { 
			return customerService.findByCustomername(cname);
		 }
}
