package com.laptopshop.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.laptopshop.entity.Brand;
import com.laptopshop.error.BrandNotFoundException;
import com.laptopshop.error.LaptopNotFoundException;
import com.laptopshop.service.BrandService;

@RestController
public class BrandController {
@Autowired
private BrandService brandService;

//add
@PostMapping("/brand")
public ResponseEntity<Brand> addBrand(@Valid @RequestBody Brand brand) {
	Brand saveBrand=brandService.addBrand(brand);
	return new ResponseEntity<Brand>(saveBrand,HttpStatus.CREATED);
	
}

//view
@GetMapping("/brand")
public List<Brand> getAllBrands(){
	return brandService.getAllBrands();
	
}

//delete
@DeleteMapping("/brand/{bid}")
public String deleteBrand(@PathVariable("bid")Integer bid) throws BrandNotFoundException  {
	brandService.deleteBrand(bid);
	return "Brand deleted successfully";
}

//update
@PutMapping("/brand/{bid}")
public Brand updateBrand(@PathVariable("bid")Integer bid, @RequestBody Brand brand) throws BrandNotFoundException  { 
	 return brandService.updateBrand(bid,brand);
	 }
//update
	@PutMapping("/brand/{bid}/laptop/{lid}")
	public Brand enrolledLaptopToBrand(@PathVariable("bid") Integer bid,@PathVariable("lid") Integer lid) throws BrandNotFoundException, LaptopNotFoundException {
		return brandService.enrolledLaptopToBrand(bid,lid);
		
	}
	
//find by id	
	@GetMapping("/brandid/{bid}")
	 public Brand findById(@PathVariable("bid")Integer bid) throws BrandNotFoundException  { 
		return brandService.findById(bid);	 
	 }
	
//find by name	
	@GetMapping("/brandname/{bname}")
	 public Brand findByBrandname(@PathVariable("bname")String bname) throws BrandNotFoundException  { 
		return brandService.findByBrandname(bname);
	 }	
}