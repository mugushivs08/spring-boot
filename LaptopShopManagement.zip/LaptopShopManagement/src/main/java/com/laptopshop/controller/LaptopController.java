package com.laptopshop.controller;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.laptopshop.entity.Laptop;
import com.laptopshop.error.CustomerNotFoundException;
import com.laptopshop.error.LaptopNotFoundException;
import com.laptopshop.repository.LaptopRepository;
import com.laptopshop.service.LaptopService;


@RestController
public class LaptopController {
@Autowired
private LaptopService laptopService;
@Autowired
private LaptopRepository laptopRepository;

//add
@PostMapping("/laptop")
public ResponseEntity<Laptop> addLaptop(@Valid @RequestBody Laptop laptop) {
	Laptop saveLaptop=laptopService.addLaptop(laptop);
	return new ResponseEntity<Laptop>(saveLaptop,HttpStatus.CREATED);
}

//view
@GetMapping("/laptop")
public List<Laptop> getAllLaptops(){
	return laptopService.getAllLaptops();	
}

//delete
@DeleteMapping("/laptop/{lid}")
public String deleteLaptop(@PathVariable("lid")Integer lid) throws LaptopNotFoundException    {
	laptopService.deleteLaptop(lid);
	return "Laptop deleted successfully";
}

//update
@PutMapping("/laptop/{lid}")
public Laptop updateLaptop(@PathVariable("lid")Integer lid, @RequestBody Laptop laptop) throws LaptopNotFoundException  { 
	 return laptopService.updateLaptop(lid,laptop);
	 }
//assign laptop to customer
	@PutMapping("/customer/{cid}/laptop/{lid}")
public Laptop assignLaptopToCustomer(@PathVariable("lid") Integer lid,@PathVariable("cid")Integer cid) throws LaptopNotFoundException, CustomerNotFoundException {
	return laptopService.assignLaptopToCustomer(lid,cid);
		
	}

//find by id	
	@GetMapping("/laptop/{lid}")
	 public Laptop findById(@PathVariable("lid")Integer lid) throws LaptopNotFoundException { 
		return laptopService.findById(lid);	 
	 }
	
//find by name	
	@GetMapping("/laptopname/{lname}")
	 public Laptop findByBrandname(@PathVariable("lname")String lname) throws LaptopNotFoundException  { 
		return laptopService.findByLaptopname(lname);
	 }	
	
//get Laptop total price	
	@GetMapping("/laptoptotalprice")
	 public float totalLaptopPrice() {
		 return laptopRepository.totalLaptopPrice();
	 }

}
