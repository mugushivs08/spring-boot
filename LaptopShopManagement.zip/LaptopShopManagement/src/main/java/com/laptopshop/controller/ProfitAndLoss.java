package com.laptopshop.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.laptopshop.repository.CustomerRepository;
import com.laptopshop.repository.LaptopRepository;
@RestController
public class ProfitAndLoss {
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	private LaptopRepository laptopRepository;
	
	
	@GetMapping("profitandloss")
	
	public String profitAndLoss() {
		
	 float pf = customerRepository.totalpayAmount()-laptopRepository.totalLaptopPrice();
	 
	 if(pf>0)
			
		return " Profit "+pf;
		
	 else
			
		return " Loss ";
	 
	}

}