package com.laptopshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaptopShopManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(LaptopShopManagementApplication.class, args);
	}

}
