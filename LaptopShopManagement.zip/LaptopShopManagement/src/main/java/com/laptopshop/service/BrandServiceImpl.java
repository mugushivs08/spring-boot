package com.laptopshop.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.laptopshop.entity.Brand;
import com.laptopshop.entity.Laptop;
import com.laptopshop.error.BrandNotFoundException;
import com.laptopshop.error.LaptopNotFoundException;
import com.laptopshop.repository.BrandRepository;
import com.laptopshop.repository.LaptopRepository;


@Service
public class BrandServiceImpl implements BrandService{
@Autowired
private BrandRepository brandRepository;
@Autowired
private LaptopRepository laptopRepository;
//add
@Override
public Brand addBrand(Brand brand) {
	return brandRepository.save(brand);
}

//view
@Override
public List<Brand> getAllBrands() {
	return brandRepository.findAll();
}

//delete
@Override
public void deleteBrand(Integer bid) throws BrandNotFoundException {
	Optional<Brand> brand=brandRepository.findById(bid);
	
	if(!brand.isPresent()) {
		throw new BrandNotFoundException("Brand id Not Exists");
	}else {
		brandRepository.deleteById(bid);;
	}
}

//update
@Override
public Brand updateBrand(Integer bid, Brand brand) throws BrandNotFoundException {
	Optional<Brand> brand1 = brandRepository.findById(bid);
	
	  if(!brand1.isPresent()) {
		  
		  throw new BrandNotFoundException("Brand Id not Found");
	  }
	  
	  else {
		  
		  Brand s= brandRepository.findById(bid).get();
		   
		    if(brand.getBrandname()!=null)
		    	
		    	s.setBrandname(brand.getBrandname());
		        
		    return brandRepository.save(s) ;
		}}

@Override
public Brand enrolledLaptopToBrand(Integer bid, Integer lid) throws BrandNotFoundException, LaptopNotFoundException{	
		Optional<Brand> brand =brandRepository.findById(bid);
		Optional<Laptop> laptop =laptopRepository.findById(lid);
	if(!brand.isPresent()) {
		throw new BrandNotFoundException("Brand id not found");
	}
	else if(!laptop.isPresent()) {
		throw new LaptopNotFoundException("Laptop id not found");
	}
	else {
		Brand b1=brandRepository.findById(lid).get();
		Laptop l1=laptopRepository.findById(lid).get();
		b1.enrollLaptop(l1);
		return brandRepository.save(b1);
	
}

}

@Override
public Brand findById(Integer bid) throws BrandNotFoundException {
		
		Optional<Brand> brand = brandRepository.findById(bid);
		
		 if(!brand.isPresent()) {
			   
			  throw new BrandNotFoundException("Brand Id not Found");	   
		   }
		   
		   else {
			   
			  return brandRepository.findById(bid).get();
		   }
	    }

@Override
public Brand findByBrandname(String bname) throws BrandNotFoundException {
		
	Brand brand = brandRepository.findByBrandname(bname);
	System.out.println("brand ="+brand);
		
		 if(brand==null) {
			   
			  throw new BrandNotFoundException("Brand Name not Found");	   
		   }
		   
		   else {
			   
			   return brandRepository.findByBrandname(bname);
		   }
	    }


		

}



