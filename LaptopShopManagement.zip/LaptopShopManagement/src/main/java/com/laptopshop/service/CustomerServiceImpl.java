package com.laptopshop.service;

import java.util.List;
import java.util.Optional;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.laptopshop.entity.Customer;
import com.laptopshop.error.CustomerNotFoundException;
import com.laptopshop.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService{
@Autowired
private CustomerRepository customerRepository;

//add
@Override
public Customer addCustomer(@Valid Customer customer) {
	return customerRepository.save(customer);
}

//view
@Override
public List<Customer> getAllCustomers() {
	return customerRepository.findAll();
}

//delete
@Override
public void deleteCustomer(Integer cid) throws CustomerNotFoundException {
	Optional<Customer> customer=customerRepository.findById(cid);
	
	if(!customer.isPresent()) {
		throw new CustomerNotFoundException("Customer id Not Exists");
	}else {
		customerRepository.deleteById(cid);;
	}
}

//update
@Override
public Customer updateCustomer(Integer cid, Customer customer)throws CustomerNotFoundException {
	Optional<Customer> customer1 = customerRepository.findById(cid);
	
	  if(!customer1.isPresent()) {
		  
		  throw new CustomerNotFoundException("Customer Id not Found");
	  }
	  
	  else {
		  
		  Customer c= customerRepository.findById(cid).get();
		   
		    if(customer.getCustomername()!=null)
		    	
		    	c.setCustomername(customer.getCustomername());
		    
		    if(customer.getCaddress()!=null)
		    	
		    	c.setCaddress(customer.getCaddress());
		    
		    if(customer.getCmobileno()!=null)
		    	
		    	c.setCmobileno(customer.getCmobileno());

		    if(customer.getCemailid()!=null)
	
		    	c.setCemailid(customer.getCemailid());
		    
		    if(customer.getcPayAmount()!=0)
		    	 
		    	 c.setcPayAmount(customer.getcPayAmount());
		        
		    return customerRepository.save(c) ;
		}
	  }

@Override
public Customer findById(Integer cid) throws CustomerNotFoundException{ 
		
		Optional<Customer> customer = customerRepository.findById(cid);
		
		 if(!customer.isPresent()) {
			   
			  throw new CustomerNotFoundException("Customer Id not Found");	   
		   }
		   
		   else {
			   
			  return customerRepository.findById(cid).get();
		   }
	    }

@Override
public Customer findByCustomername(String cname)throws CustomerNotFoundException {
			
		Customer customer = customerRepository.findByCustomername(cname);
		System.out.println("customer ="+customer);
			
			 if(customer==null) {
				   
				  throw new CustomerNotFoundException("Customer Name not Found");	   
			   }
			   
			   else {
				   
				   return customerRepository.findByCustomername(cname);
			   }
		    }




}