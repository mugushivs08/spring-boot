package com.laptopshop.service;

import java.util.List;
import javax.validation.Valid;
import com.laptopshop.entity.Laptop;
import com.laptopshop.error.CustomerNotFoundException;
import com.laptopshop.error.LaptopNotFoundException;

public interface LaptopService {

	Laptop addLaptop(@Valid Laptop laptop);

	List<Laptop> getAllLaptops();

	void deleteLaptop(Integer lid) throws LaptopNotFoundException;

	Laptop updateLaptop(Integer lid, Laptop laptop) throws LaptopNotFoundException;

	Laptop assignLaptopToCustomer(Integer lid, Integer cid) throws LaptopNotFoundException, CustomerNotFoundException;

	Laptop findById(Integer lid) throws LaptopNotFoundException;

	Laptop findByLaptopname(String lname) throws LaptopNotFoundException;





	



}
