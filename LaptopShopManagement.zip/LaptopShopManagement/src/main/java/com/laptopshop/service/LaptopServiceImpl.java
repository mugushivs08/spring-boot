package com.laptopshop.service;

import java.util.List;
import java.util.Optional;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.laptopshop.entity.Customer;
import com.laptopshop.entity.Laptop;
import com.laptopshop.error.CustomerNotFoundException;
import com.laptopshop.error.LaptopNotFoundException;
import com.laptopshop.repository.CustomerRepository;
import com.laptopshop.repository.LaptopRepository;



@Service
public class LaptopServiceImpl implements LaptopService{
@Autowired
private LaptopRepository laptopRepository;
@Autowired
private CustomerRepository customerRepository;

//add
@Override
public Laptop addLaptop(@Valid Laptop laptop) {
	return laptopRepository.save(laptop);
}

//view
@Override
public List<Laptop> getAllLaptops() {
	return laptopRepository.findAll();
}

//delete
@Override
public void deleteLaptop(Integer lid) throws LaptopNotFoundException{
Optional<Laptop> laptop=laptopRepository.findById(lid);
	
	if(!laptop.isPresent()) {
		throw new LaptopNotFoundException("Laptop id Not Exists");
	}else {
		laptopRepository.deleteById(lid);
	}	

}

//update
@Override
public Laptop updateLaptop(Integer lid, Laptop laptop)throws LaptopNotFoundException {
	Optional<Laptop> laptop1 = laptopRepository.findById(lid);
	
	  if(!laptop1.isPresent()) {
		  
		  throw new LaptopNotFoundException("Laptop Id not Found");
	  }
	  
	  else {
		  
		  Laptop l= laptopRepository.findById(lid).get();
		   
		    if(laptop.getLaptopname()!=null)
		    	
		    	l.setLaptopname(laptop.getLaptopname());
		    
		    if(laptop.getLprocess()!=null)
		    	
		    	l.setLprocess(laptop.getLprocess());
		   
		    if(laptop.getlRAM()!=null)
		    	
		    	l.setlRAM(laptop.getlRAM());
		        
		    if(laptop.getlOS()!=null)
		    	
		    	l.setlOS(laptop.getlOS());
		    
		    if(laptop.getLweight()!=null)
		    	
		    	l.setLweight(laptop.getLweight());
		    
		    if(laptop.getlStorage()!=null)
		    	
		    	l.setlStorage(laptop.getlStorage());
		    
		    if(laptop.getLprice()!=0)
		    	 
		    	 l.setLprice(laptop.getLprice());
		        
		    return laptopRepository.save(l) ;
		}
	  }

@Override
public Laptop assignLaptopToCustomer(Integer lid, Integer cid) throws LaptopNotFoundException, CustomerNotFoundException {

		Optional<Laptop> laptop = laptopRepository.findById(lid);
		
		Optional<Customer> customer = customerRepository.findById(cid);
		if(!laptop.isPresent()){
			throw new LaptopNotFoundException("Laptop not found");
		}else if(!customer.isPresent()) {
			throw new CustomerNotFoundException("Customer not fount");
		}else {
			Laptop l1=laptopRepository.findById(cid).get();
			Customer c1=customerRepository.findById(lid).get();
			l1.assignCustomer(c1);
		return laptopRepository.save(l1) ;
	}


}

@Override
public Laptop findById(Integer lid)throws LaptopNotFoundException{
			
			Optional<Laptop> laptop = laptopRepository.findById(lid);
			
			 if(!laptop.isPresent()) {
				   
				  throw new LaptopNotFoundException("Laptop Id not Found");	   
			   }
			   
			   else {
				   
				  return laptopRepository.findById(lid).get();
			   }
		    }

@Override
public Laptop findByLaptopname(String lname) throws LaptopNotFoundException{
			
		Laptop laptop = laptopRepository.findByLaptopname(lname);
		System.out.println("laptop ="+laptop);
			
			 if(laptop==null) {
				   
				  throw new LaptopNotFoundException("Laptop Name not Found");	   
			   }
			   
			   else {
				   
				   return laptopRepository.findByLaptopname(lname);
			   }
		    }


}


