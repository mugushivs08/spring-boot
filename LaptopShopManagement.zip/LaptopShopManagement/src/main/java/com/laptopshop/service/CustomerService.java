package com.laptopshop.service;

import java.util.List;

import javax.validation.Valid;

import com.laptopshop.entity.Customer;
import com.laptopshop.error.CustomerNotFoundException;

public interface CustomerService {

	Customer addCustomer(@Valid Customer customer);

	List<Customer> getAllCustomers();

	void deleteCustomer(Integer cid) throws CustomerNotFoundException;

	Customer updateCustomer(Integer cid, Customer customer) throws CustomerNotFoundException;

	Customer findById(Integer cid) throws CustomerNotFoundException;

	Customer findByCustomername(String cname) throws CustomerNotFoundException;




}
