package com.laptopshop.service;

import java.util.List;

import com.laptopshop.entity.Brand;
import com.laptopshop.error.BrandNotFoundException;
import com.laptopshop.error.LaptopNotFoundException;

public interface BrandService {

	Brand addBrand(Brand brand);

	List<Brand> getAllBrands();

	void deleteBrand(Integer bid) throws BrandNotFoundException;

	Brand updateBrand(Integer bid, Brand brand) throws BrandNotFoundException;

	Brand enrolledLaptopToBrand(Integer bid, Integer lid) throws BrandNotFoundException, LaptopNotFoundException;

	Brand findById(Integer bid) throws BrandNotFoundException;


	Brand findByBrandname(String bname) throws BrandNotFoundException;


	



	
}
