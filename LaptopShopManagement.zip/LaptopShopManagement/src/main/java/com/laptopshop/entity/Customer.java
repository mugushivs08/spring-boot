package com.laptopshop.entity;


import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import org.springframework.lang.NonNull;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
public class Customer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer cid;
	
	@NotEmpty
	@Size(min=3, max=30, message= "Name should be min 3 aur max 30 character")
	private String customername;
	
	@NotEmpty(message = "Customer Address should not be empty")
	private String caddress;
	
	@NotEmpty
	@Min(value=10, message= "Mobile Number should be 10 digit")
	private String cmobileno;
	
	@NotEmpty(message="UserEmail id should not be blank or not null" )
	@Email(message="Invalid Email id")
	private String cemailid;
	
	@NonNull
	 @Min(value=10000)
	 @Max(value=100000)
	 private Float cPayAmount; 

	
//relation 
	
	@JsonIgnore
	@OneToMany(mappedBy = "customer")
	private Set<Laptop> laptop=new HashSet<>();
	
	
	public Set<Laptop> getLaptop() {
		return laptop;
	}

	public void setLaptop(Set<Laptop> laptop) {
		this.laptop = laptop;
	}
///
	
	public Integer getCid() {
		return cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public String getCaddress() {
		return caddress;
	}

	public void setCaddress(String caddress) {
		this.caddress = caddress;
	}

	public String getCmobileno() {
		return cmobileno;
	}

	public void setCmobileno(String cmobileno) {
		this.cmobileno = cmobileno;
	}

	public String getCemailid() {
		return cemailid;
	}

	public void setCemailid(String cemailid) {
		this.cemailid = cemailid;
	}

	public Float getcPayAmount() {
		return cPayAmount;
	}

	public void setcPayAmount(Float cPayAmount) {
		this.cPayAmount = cPayAmount;
	}
	
	
}
