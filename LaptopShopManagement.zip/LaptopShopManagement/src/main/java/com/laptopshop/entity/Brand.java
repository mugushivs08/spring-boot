package com.laptopshop.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Entity
public class Brand {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer bid;

@NotEmpty(message = "Barnd Name Should Not Be Empty")
@Size(min=3, max=30, message="Name Should be min 2 chars and max=30 chars")
	
private String brandname;

//relation 
@ManyToMany
@JoinTable(
		name="laptop_enrolled", joinColumns = @JoinColumn(name="brand_id"),

        inverseJoinColumns = @JoinColumn(name="laptop_id")
)

Set<Laptop>enrolledlaptop=new HashSet<>();

public Set<Laptop> getEnrolledlaptop() {
	return enrolledlaptop;
}

public void setEnrolledlaptop(Set<Laptop> enrolledlaptop) {
	this.enrolledlaptop = enrolledlaptop;
}


///////


public Integer getBid() {
	return bid;
}

public void setBid(Integer bid) {
	this.bid = bid;
}

public String getBrandname() {
	return brandname;
}

public void setBrandname(String brandname) {
	this.brandname = brandname;
}

public void enrollLaptop(Laptop laptop) {
enrolledlaptop.add(laptop);	
}


}
