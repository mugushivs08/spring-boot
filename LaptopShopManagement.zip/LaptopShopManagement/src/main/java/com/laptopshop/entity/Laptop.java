package com.laptopshop.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import org.springframework.lang.NonNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity

public class Laptop {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer lid;
	
	@NotEmpty(message = "Laptop name should not be empty")
	@Size(min=3, max=30, message="Laptop name should be min 2 chars and max=30 chars")
	private String laptopname;
	
	@NotEmpty(message = "Laptop process should not be empty")
	private String lprocess;
	
	@NotEmpty(message = "Laptop RAM should not be empty")
	 private String lRAM;
	
	@NotEmpty(message = "Laptop Storage should not be empty")
	 private String lStorage;
	
	@NotEmpty(message = "Laptop OS should not be empty")
	private String lOS;
	
	@NotEmpty(message = "Laptop OS should not be empty")
	private String lweight;
	
	@NonNull
	 @Min(value=10000)
	 @Max(value=100000)
	 private Float lprice; 

	
	//relation many to one
	//Inside laptop class add customer

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="Customer_Id", referencedColumnName = "cid")
	
	private Customer customer;
	

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	//////////brand to Laptop
	@JsonIgnore
	@ManyToMany(mappedBy ="enrolledlaptop")
	private Set<Brand> brands=new HashSet<>();
	
	
	public Set<Brand> getBrands() {
		return brands;
	}

	public void setBrands(Set<Brand> brands) {
		this.brands = brands;
	}

	//////
	public Integer getLid() {
		return lid;
	}

	public void setLid(Integer lid) {
		this.lid = lid;
	}


	public String getLaptopname() {
		return laptopname;
	}

	public void setLaptopname(String laptopname) {
		this.laptopname = laptopname;
	}

	public Float getLprice() {
		return lprice;
	}

	public void setLprice(Float lprice) {
		this.lprice = lprice;
	}

	

	public String getlOS() {
		return lOS;
	}

	public void setlOS(String lOS) {
		this.lOS = lOS;
	}

	

	public String getlStorage() {
		return lStorage;
	}

	public void setlStorage(String lStorage) {
		this.lStorage = lStorage;
	}

	public String getlRAM() {
		return lRAM;
	}

	public void setlRAM(String lRAM) {
		this.lRAM = lRAM;
	}

	public String getLweight() {
		return lweight;
	}

	public void setLweight(String lweight) {
		this.lweight = lweight;
	}

	public String getLprocess() {
		return lprocess;
	}

	public void setLprocess(String lprocess) {
		this.lprocess = lprocess;
	}

	public void assignCustomer(Customer customer2) {
		this.customer=customer2;
		
	}
	

}
