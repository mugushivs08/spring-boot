package com.laptopshop.error;

public class LaptopNotFoundException extends Exception {
	public LaptopNotFoundException(String message) {
		super(message);
	}

}
